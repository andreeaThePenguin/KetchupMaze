#ifndef __LOADERS_MB2_GDT_H__
#define __LOADERS_MB2_GDT_H__

void InitLinuxDescriptorTables();
void SetLinuxDescriptorTables();

#endif //__LOADERS_MB2_GDT_H__
