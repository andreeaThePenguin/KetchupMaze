#ifndef TOMATOS_ACPIUTILS_H
#define TOMATOS_ACPIUTILS_H

#include <ProcessorBind.h>

void* GetAcpiTable(UINT32 Signature);

#endif //TOMATOS_ACPIUTILS_H
